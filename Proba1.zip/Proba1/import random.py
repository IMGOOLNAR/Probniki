import random
from datetime import datetime

# Путь для сохранения файлов
DOWNLOAD_PATH = "chapters/"
N = 0

# Класс для главы книги
class Chapter:
    def __init__(self, title, author, content):
        self.title = title
        self.author = author
        self.content = content
        self.likes = random.randint(0, 100)
        self.creation_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    def to_string(self):
        return (
            f"Title: {self.title}\n"
            f"Author: {self.author}\n"
            f"Content: {self.content}\n"
            f"Likes: {self.likes}\n"
            f"Creation Date: {self.creation_date}\n"
        )

# Генерация случайного заголовка для главы
def generate_random_title():
    themes = ["Приключения", "Загадки", "Научная фантастика", "Фэнтези", "Исторический роман"]
    actions = ["Путешествие", "Тайна", "Сражение", "Открытие", "Исследование"]
    subjects = ["в далекой стране", "в заброшенном замке", "на краю вселенной", "в древнем городе", "в мире чудес"]
    
    title = f"{random.choice(themes)}: {random.choice(actions)} {random.choice(subjects)}"
    return title

# Сохранение главы в текстовом формате
def save_chapter(chapter):
    global N
    N += 1
    current_time = datetime.now().strftime('%Y%m%d_%H%M%S')
    file_path = f"{DOWNLOAD_PATH}chapter_{N}_{current_time}.txt"
    
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(chapter.to_string())

# Генерация главы книги
def get_chapter():
    title = generate_random_title()
    author = f"Автор_{random.randint(1, 100)}"
    content = f"Содержание главы '{title.lower()}'. Здесь будет рассказано о событиях, происходящих в главе."
    
    return Chapter(title, author, content)

# Основная работа программы
def do_work():
    chapter = get_chapter()
    save_chapter(chapter)

# Создание и сохранение 10 глав книги
for _ in range(10):
    do_work()

print("Главы созданы!")
