import datetime
import random
import logging
import os

# Настройка логирования
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

_DOWNLOAD_PATH = "Download/"
_N = 0

class Note:
    def __init__(self, title, author, content):
        self.title = title
        self.author = author
        self.content = content
        self.creation_date = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

def generate_random_note_title():
    """Генерирует случайное название заметки."""
    titles = [
        "Заметка о {topic}",
        "Мысли на тему {topic}",
        "Идеи по {topic}",
        "План на {topic}",
        "Обсуждение {topic}",
    ]
    topics = ["продуктивности", "здоровье", "образовании", "путешествиях", "финансах"]
    title_template = random.choice(titles)
    return title_template.format(topic=random.choice(topics))

def txt_dump_note(note: Note):
    global _N
    _N += 1
    dt = datetime.datetime.now()
    dt_str = dt.strftime('%Y-%m-%d_%H-%M-%S')
    path = f'{_DOWNLOAD_PATH}{_N}_{dt_str}.txt'
    
    # Проверка существования директории для сохранения заметок
    os.makedirs(_DOWNLOAD_PATH, exist_ok=True)
    
    with open(path, 'w', encoding='utf-8') as f:
        f.write(f"Заголовок: {note.title}\n")
        f.write(f"Автор: {note.author}\n")
        f.write(f"Дата создания: {note.creation_date}\n")
        f.write(f"Содержание:\n{note.content}\n")
    
    logging.info(f'Заметка сохранена: {path}')

def get_note():
    title = generate_random_note_title()
    author = f"Автор {random.randint(1, 100)}"
    content = f"Это содержание заметки с заголовком '{title}'. Здесь можно записать свои мысли и идеи."
    note = Note(title, author, content)
    
    logging.info(f'Создана новая заметка: {title} от {author}')
    
    return note

def do_work():
    note = get_note()
    txt_dump_note(note)

# Создание и сохранение 10 заметок
for _ in range(10):
    do_work()

print('Заметки успешно созданы!')
